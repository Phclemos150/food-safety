import { Component } from '@angular/core';
import { Router } from '@angular/router'; // Importa Router
import { MenuController } from '@ionic/angular'; // Importa MenuController

@Component({
  selector: 'app-root',
  templateUrl: 'app.component.html',
  styleUrls: ['app.component.scss'],
  standalone: false,
})
export class AppComponent {
  constructor(private router: Router, private menu: MenuController) {}

  async irParaMinhaConta() {
    await this.menu.close(); // Fecha o menu antes de ir
    this.router.navigate(['/usuario']); // Navega para a página "Minha Conta"
  }
}
