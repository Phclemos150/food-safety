import { Component } from '@angular/core';
import { IonicModule } from '@ionic/angular';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { AuthService } from '../services/auth.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-register',
  standalone: true,                // <-- componente standalone
  imports: [IonicModule, CommonModule, FormsModule],  // módulos usados no template
  templateUrl: './register.page.html',
  styleUrls: ['./register.page.scss'],
})
export class RegisterPage {
  email = '';
  password = '';
  errorMessage = '';

  constructor(private authService: AuthService, private router: Router) {}

  async onRegister() {
    try {
      await this.authService.register(this.email, this.password);
      this.errorMessage = '';
      this.router.navigateByUrl('/home', { replaceUrl: true });
    } catch (error) {
      this.errorMessage = 'Erro ao criar conta. Tente novamente.';
      console.error(error);
    }
  }
}
