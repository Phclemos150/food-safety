import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { AuthService } from '../services/auth.service'; // importe seu serviço de autenticação

@Component({
  selector: 'app-usuario',
  templateUrl: './usuario.page.html',
  styleUrls: ['./usuario.page.scss'],
  standalone: false
})
export class UsuarioPage implements OnInit {
  user: any = null;

  constructor(private router: Router, private authService: AuthService) {}

  ngOnInit() {
    this.getCurrentUser();
  }

  async getCurrentUser() {
    this.user = await this.authService.getUser();
  }

  irParaHome() {
    this.router.navigate(['tabs/home']);
  }

  irParaLogin() {
    this.router.navigate(['/login']);
  }

  irParaRegister() {
    this.router.navigate(['/register']);
  }

  async logout() {
    await this.authService.logout();
    this.user = null;
  }
}
