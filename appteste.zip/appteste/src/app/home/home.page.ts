import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { HttpClient } from '@angular/common/http';

@Component({
  selector: 'app-home',
  templateUrl: './home.page.html',
  styleUrls: ['./home.page.scss'],
  standalone: false
})
export class HomePage implements OnInit {

  receitaDoDia: any;
  categorias: any[] = [];
  populares: any[] = [];
  sugestao: any;

  constructor(private router: Router, private http: HttpClient) {}

  ngOnInit() {
    this.buscarReceitaDoDia();
    this.buscarCategorias();
    this.buscarPopulares('Beef'); // categoria de exemplo
    this.buscarSugestao('Seafood'); // pode ser personalizada
  }

  toggleTheme() {
    document.body.classList.toggle('dark');
  }

  irParaUsuario() {
    this.router.navigate(['/usuario']);
  }

  irParaConfiguracoes() {
    if (navigator.share) {
      navigator.share({
        title: 'Food Safety',
        text: 'Confira este app incrível de receitas saudáveis!',
        url: 'https://facebook.com/@nicollaslm2'
      }).then(() => {
        console.log('Compartilhamento bem-sucedido');
      }).catch((error) => {
        console.log('Erro ao compartilhar:', error);
      });
    } else {
      alert('O compartilhamento não é suportado neste navegador.');
    }
  }

  irParaPoliticas() {
    this.router.navigate(['/politicas']);
  }

  irParaTemas() {
    this.router.navigate(['/temas']);
  }

  // === Integração com TheMealDB ===

  buscarReceitaDoDia() {
    this.http.get<any>('https://www.themealdb.com/api/json/v1/1/random.php')
      .subscribe(res => {
        this.receitaDoDia = res.meals[0];
      });
  }

  buscarCategorias() {
    this.http.get<any>('https://www.themealdb.com/api/json/v1/1/categories.php')
      .subscribe(res => {
        this.categorias = res.categories;
      });
  }

  buscarPopulares(categoria: string) {
    this.http.get<any>(`https://www.themealdb.com/api/json/v1/1/filter.php?c=${categoria}`)
      .subscribe(res => {
        this.populares = res.meals.slice(0, 2);
      });
  }

  buscarSugestao(categoria: string) {
    this.http.get<any>(`https://www.themealdb.com/api/json/v1/1/filter.php?c=${categoria}`)
      .subscribe(res => {
        this.sugestao = res.meals[0];
      });
  }

  abrirDetalhe(id: string) {
    this.router.navigate(['/detalhe', id]);
  }

  abrirCategoria(nomeCategoria: string) {
    this.router.navigate(['/categoria', nomeCategoria]);
  }

}
