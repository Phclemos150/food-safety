export const environment = {
  production: true,
  myMemoryApiKey: 'c066d58f740eec6fe8fc',
  firebaseConfig: {
    apiKey: "AIzaSyC7El6f_Ef-WIYRodaoDoNQy1tl6LyKjjk",
    authDomain: "food-safety-2c53d.firebaseapp.com",
    projectId: "food-safety-2c53d",
    storageBucket: "food-safety-2c53d.appspot.com",
    messagingSenderId: "294396070534",
    appId: "1:294396070534:web:78548ad8bfe635d63c5f07",
    measurementId: "G-RKEB1HJJZR"
  }
};
