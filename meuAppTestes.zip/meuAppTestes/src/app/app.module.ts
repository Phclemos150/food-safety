import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { RouteReuseStrategy } from '@angular/router';

import { IonicModule, IonicRouteStrategy } from '@ionic/angular';
import { AppComponent } from './app.component';
import { AppRoutingModule } from './app-routing.module';

import { FormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';

// Firebase direto, sem @angular/fire
import { initializeApp } from 'firebase/app';
import { getAuth } from 'firebase/auth';  // Importa diretamente a autenticação do Firebase

import { environment } from '../environments/environment';  // Importa as configurações do Firebase

@NgModule({
  declarations: [AppComponent],
  imports: [
    BrowserModule,
    IonicModule.forRoot(),
    AppRoutingModule,
    FormsModule,
    HttpClientModule
  ],
  providers: [{ provide: RouteReuseStrategy, useClass: IonicRouteStrategy }],
  bootstrap: [AppComponent],
})
export class AppModule {
  constructor() {
    // Inicialize o Firebase com a configuração do environment.ts
    const app = initializeApp(environment.firebaseConfig);  // Acesse a configuração diretamente de environment.firebaseConfig
    const auth = getAuth(app);  // Inicializa a autenticação do Firebase
  }
}
