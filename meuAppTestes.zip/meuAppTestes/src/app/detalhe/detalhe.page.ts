import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { HttpClient } from '@angular/common/http';

@Component({
  selector: 'app-detalhe',
  templateUrl: './detalhe.page.html',
  styleUrls: ['./detalhe.page.scss'],
  standalone: false,
})
export class DetalhePage implements OnInit {
  receita: any;

  constructor(private route: ActivatedRoute, private http: HttpClient) {}

  ngOnInit() {
    const id = this.route.snapshot.paramMap.get('id');
    this.http.get<any>(`https://www.themealdb.com/api/json/v1/1/lookup.php?i=${id}`)
      .subscribe(res => {
        this.receita = res.meals[0];
      });
  }
}