import { Component, OnInit } from '@angular/core';
import { AuthService } from './services/auth.service';
import { Router } from '@angular/router';
import { getAuth, onAuthStateChanged } from 'firebase/auth';

@Component({
  selector: 'app-root',
  templateUrl: 'app.component.html',
  styleUrls: ['app.component.scss'],
  standalone:false
})
export class AppComponent implements OnInit {
  user: any = null;  // Aqui você armazenará as informações do usuário
  email: string | null = null;  // A variável pode ser string ou null inicialmente
  
  constructor(private authService: AuthService, private router: Router) {}

  ngOnInit() {
    const auth = getAuth();

    // Verifica o estado da autenticação
    onAuthStateChanged(auth, (user) => {
      if (user) {
        this.user = user;  // Atribui as informações do usuário logado
        this.email = user.email;  // Exemplo de acessar o email do usuário
        console.log('Usuário logado:', user);
        // Redireciona para a página inicial
        this.router.navigate(['tabs/home']);
      } else {
        console.log('Usuário não autenticado');
        // Redireciona para a tela de login
        this.router.navigate(['login']);
      }
    });
  }
}
