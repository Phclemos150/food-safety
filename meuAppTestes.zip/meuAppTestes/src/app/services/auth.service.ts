import { Injectable } from '@angular/core';
import { initializeApp } from 'firebase/app';
import { getAuth, signInWithEmailAndPassword, createUserWithEmailAndPassword } from 'firebase/auth';
import { environment } from '../../environments/environment';
import { signOut } from 'firebase/auth';



@Injectable({
  providedIn: 'root',
})
export class AuthService {
  private auth = getAuth(initializeApp(environment.firebaseConfig));

  constructor() {}

  // Função de login
  login(email: string, password: string) {
    return new Promise((resolve, reject) => {
      signInWithEmailAndPassword(this.auth, email, password)
        .then((userCredential) => {
          resolve(userCredential.user);
        })
        .catch((error) => {
          reject(error);
        });
    });
  }

  logout() {
    return signOut(this.auth);
  }

  // Função de registro
  register(email: string, password: string) {
    return new Promise((resolve, reject) => {
      createUserWithEmailAndPassword(this.auth, email, password)
        .then((userCredential) => {
          resolve(userCredential.user);  // Retorna o usuário autenticado
        })
        .catch((error) => {
          reject(error);
        });
    });
  }
}
