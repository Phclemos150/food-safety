import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { AuthService } from '../services/auth.service';  // Seu serviço de autenticação

@Component({
  selector: 'app-usuario',
  templateUrl: './usuario.page.html',
  styleUrls: ['./usuario.page.scss'],
  standalone: false
})
export class UsuarioPage {
  email: string = '';  // E-mail digitado pelo usuário
  password: string = '';  // Senha digitada pelo usuário

  constructor(private authService: AuthService, private router: Router) {}

  // Função de login
  login() {
    if (this.email && this.password) {
      this.authService.login(this.email, this.password)
        .then(user => {
          console.log('Usuário logado com sucesso:', user);
          this.router.navigate(['tabs/home']);  // Redireciona para a home após login
        })
        .catch(error => {
          console.error('Erro ao fazer login:', error);
          alert('Erro ao fazer login: ' + error.message);
        });
    } else {
      alert('Por favor, preencha todos os campos.');
    }
  }

  // Função de registro
  register() {
    if (this.email && this.password) {
      this.authService.register(this.email, this.password)
        .then(user => {
          console.log('Usuário registrado com sucesso:', user);
          this.router.navigate(['tabs/home']);  // Redireciona para a home após registro
        })
        .catch(error => {
          console.error('Erro ao registrar:', error);
          alert('Erro ao registrar: ' + error.message);
        });
    } else {
      alert('Por favor, preencha todos os campos.');
    }
  }
}
