import { Component, OnInit } from '@angular/core';
import { FavoritosService } from '../services/favorites.service';
import { Router } from '@angular/router';
import { TranslationService } from '../services/translation.service';  // IMPORTAR

@Component({
  selector: 'app-favoritos',
  templateUrl: './favoritos.page.html',
  styleUrls: ['./favoritos.page.scss'],
  standalone: false
})
export class FavoritosPage implements OnInit {
  favoritos: any[] = [];

  constructor(
    private favoritosService: FavoritosService,
    private router: Router,
    private translationService: TranslationService  // INJETAR
  ) {}

  ngOnInit() {
    this.carregarFavoritos();
  }

  async carregarFavoritos() {
    this.favoritos = this.favoritosService.getFavoritos();
    // Traduzir nomes das receitas favoritas
    for (let receita of this.favoritos) {
      receita.strMeal = await this.translationService.traduzir(receita.strMeal);
    }
  }

  abrirDetalhe(id: string) {
    this.router.navigate(['/detalhe', id]);
  }

  removerFavorito(id: string, event: Event) {
    event.stopPropagation();  // evita abrir o detalhe ao clicar no coração
    this.favoritosService.removerFavorito(id);
    this.carregarFavoritos();  // atualiza lista local para refletir a remoção
  }
}
