import { Component } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-usuario',
  templateUrl: './usuario.page.html',
  styleUrls: ['./usuario.page.scss'],
  standalone: false
})
export class UsuarioPage {

  constructor(private router: Router) {}

  irParaHome() {
    this.router.navigate(['tabs/home']);
  }

}