import { Component } from '@angular/core';

@Component({
  selector: 'app-feed',
  templateUrl: './feed.page.html',
  styleUrls: ['./feed.page.scss'],
  standalone: false
})
export class FeedPage {
  noticias = [
    {
      titulo: 'Alimentação saudável: o que é, benefícios e como fazer (com dicas)',
      descricao: 'Uma nova receita de salada viralizou nas redes sociais por ser prática e deliciosa.',
      imagem: 'https://image.tuasaude.com/media/article/ep/cs/alimentacao-e-saude_25100.jpg?width=686&height=487',
      data: new Date('2025-05-01'),
      link: 'https://www.tuasaude.com/alimentacao-e-saude/'
    },
    {
      titulo: 'Reeducação alimentar: o que é, como fazer e cardápio',
      descricao: 'Especialistas ensinam como montar uma lista de compras inteligente e econômica.',
      imagem: 'https://image.tuasaude.com/media/article/ci/vf/emagrecer-com-reeducacao-alimentar_11420.jpg?width=686&height=487',
      data: new Date('2025-05-10'),
      link: 'https://www.tuasaude.com/emagrecer-com-reeducacao-alimentar/'
    },
     {
      titulo: '11 dicas imperdíveis para ter uma alimentação equilibrada',
      descricao: 'Dicas valiosas para manter uma alimentação equilibrada, enfatizando o consumo de alimentos naturais e a importância de uma dieta variada.',
      imagem: 'https://vidasaudavel.einstein.br/wp-content/uploads/2022/07/alimentacao-equilibrada.jpeg',
      data: new Date('2024-10-17'),
      link: 'https://vidasaudavel.einstein.br/alimentacao-equilibrada/'
    },
    {
      titulo: 'Alimentação saudável',
      descricao: 'Este portal do Ministério da Saúde oferece orientações sobre alimentação saudável, destacando a importância de consumir alimentos in natura e minimamente processados.',
      imagem: 'https://bvsms.saude.gov.br/wp-content/uploads/2020/12/alimentacao_saudavel-300x164.jpg',
      data: new Date('2010-05-02'),
      link: 'https://bvsms.saude.gov.br/alimentacao-saudavel/'
    },
    {
      titulo: 'Alimentação saudável contribui para melhora da imunidade e de quadros de estresse e ansiedade',
      descricao: 'Matéria que explora como uma alimentação balanceada pode fortalecer o sistema imunológico e auxiliar no controle do estresse e da ansiedade.',
      imagem: 'https://saude.es.gov.br/Media/sesa/_Profiles/c4d8c6e6/f3f2cd0/cpa%20de%20materia.png?v=638730375321375980',
      data: new Date('2021-10-17'),
      link: 'https://saude.es.gov.br/Not%C3%ADcia/alimentacao-saudavel-contribui-para-melhora-da-imunidade-e-de-quadros-de-estresse-e-ansiedade'
    },
    {
      titulo: 'Alimentação saudável: o que é, benefícios e como fazer (com dicas)',
      descricao: 'Uma nova receita de salada viralizou nas redes sociais por ser prática e deliciosa.',
      imagem: 'https://image.tuasaude.com/media/article/ep/cs/alimentacao-e-saude_25100.jpg?width=686&height=487',
      data: new Date('2025-05-01'),
      link: 'https://www.tuasaude.com/alimentacao-e-saude/'
    },
    {
      titulo: 'Alimentação saudável: o que é, benefícios e como fazer (com dicas)',
      descricao: 'Uma nova receita de salada viralizou nas redes sociais por ser prática e deliciosa.',
      imagem: 'https://image.tuasaude.com/media/article/ep/cs/alimentacao-e-saude_25100.jpg?width=686&height=487',
      data: new Date('2025-05-01'),
      link: 'https://www.tuasaude.com/alimentacao-e-saude/'
    },
    {
      titulo: 'Alimentação saudável: o que é, benefícios e como fazer (com dicas)',
      descricao: 'Uma nova receita de salada viralizou nas redes sociais por ser prática e deliciosa.',
      imagem: 'https://image.tuasaude.com/media/article/ep/cs/alimentacao-e-saude_25100.jpg?width=686&height=487',
      data: new Date('2025-05-01'),
      link: 'https://www.tuasaude.com/alimentacao-e-saude/'
    },
    {
      titulo: 'Alimentação saudável: o que é, benefícios e como fazer (com dicas)',
      descricao: 'Uma nova receita de salada viralizou nas redes sociais por ser prática e deliciosa.',
      imagem: 'https://image.tuasaude.com/media/article/ep/cs/alimentacao-e-saude_25100.jpg?width=686&height=487',
      data: new Date('2025-05-01'),
      link: 'https://www.tuasaude.com/alimentacao-e-saude/'
    },
    {
      titulo: 'Como economizar e ter uma alimentação adequada e saudável?',
      descricao: 'Dicas para manter uma alimentação saudável sem gastar muito, incluindo sugestões de compras e armazenamento de alimentos.',
      imagem: 'https://www.gov.br/saude/pt-br/assuntos/saude-brasil/eu-quero-me-alimentar-melhor/noticias/2022/como-economizar-e-ter-uma-alimentacao-adequada-e-saudavel/como-economizar-e-ter-uma-alimentacao-saudavel_1280x530px.png/@@images/f6322e56-73de-43cd-8f8d-b3c7306c369e.png',
      data: new Date('2022-05-25'),
      link: 'https://www.gov.br/saude/pt-br/assuntos/saude-brasil/eu-quero-me-alimentar-melhor/noticias/2022/como-economizar-e-ter-uma-alimentacao-adequada-e-saudavel'
    }
  ];

  formatarData(data: Date): string {
    return new Intl.DateTimeFormat('pt-BR', {
      day: '2-digit',
      month: 'short',
      year: 'numeric'
    }).format(data);
  }
}