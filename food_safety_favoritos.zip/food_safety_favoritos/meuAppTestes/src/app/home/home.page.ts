import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { HttpClient } from '@angular/common/http';
import { FavoritosService } from '../services/favorites.service';
import { ToastController } from '@ionic/angular'; // ✅ Importação do toast

@Component({
  selector: 'app-home',
  templateUrl: './home.page.html',
  styleUrls: ['./home.page.scss'],
  standalone: false
})
export class HomePage implements OnInit {

  receitaDoDia: any;
  categorias: any[] = [];
  populares: any[] = [];
  sugestao: any;

  constructor(
    private router: Router,
    private http: HttpClient,
    private favoritosService: FavoritosService,
    private toastController: ToastController // ✅ Injeção do toast
  ) {}

  ngOnInit() {
    this.buscarReceitaDoDia();
    this.buscarCategorias();
    this.buscarPopulares('Beef');
    this.buscarSugestao('Seafood');
  }

  irParaUsuario() {
    this.router.navigate(['/usuario']);
  }

  irParaConfiguracoes() {
    if (navigator.share) {
      navigator.share({
        title: 'Food Safety',
        text: 'Confira este app incrível de receitas saudáveis!',
        url: 'https://facebook.com/@nicollaslm2'
      }).then(() => {
        console.log('Compartilhamento bem-sucedido');
      }).catch((error) => {
        console.log('Erro ao compartilhar:', error);
      });
    } else {
      alert('O compartilhamento não é suportado neste navegador.');
    }
  }

  irParaPoliticas() {
    this.router.navigate(['/politicas']);
  }

  irParaTemas() {
    this.router.navigate(['/temas']);
  }

  buscarReceitaDoDia() {
    this.http.get<any>('https://www.themealdb.com/api/json/v1/1/random.php')
      .subscribe(res => {
        this.receitaDoDia = res.meals[0];
      });
  }

  buscarCategorias() {
    this.http.get<any>('https://www.themealdb.com/api/json/v1/1/categories.php')
      .subscribe(res => {
        this.categorias = res.categories;
      });
  }

  buscarPopulares(categoria: string) {
    this.http.get<any>(`https://www.themealdb.com/api/json/v1/1/filter.php?c=${categoria}`)
      .subscribe(res => {
        this.populares = res.meals.slice(0, 2); // mostra só 2 receitas
      });
  }

  buscarSugestao(categoria: string) {
    this.http.get<any>(`https://www.themealdb.com/api/json/v1/1/filter.php?c=${categoria}`)
      .subscribe(res => {
        this.sugestao = res.meals[0];
      });
  }

  abrirDetalhe(id: string) {
    this.router.navigate(['/detalhe', id]);
  }

  abrirCategoria(nomeCategoria: string) {
    this.router.navigate(['/categoria', nomeCategoria]);
  }

  toggleFavorito(receita: any) {
    const mensagem = this.isFavorito(receita.idMeal)
      ? 'Removido dos favoritos'
      : 'Adicionado aos favoritos';

    this.favoritosService.toggleFavorito(receita);
    this.mostrarToast(mensagem);

    // Atualiza referências para o Angular detectar mudanças e atualizar os ícones:
    this.populares = [...this.populares];
    this.receitaDoDia = { ...this.receitaDoDia };
    this.sugestao = { ...this.sugestao };
  }

  isFavorito(id: string): boolean {
    return this.favoritosService.isFavorito(id);
  }

  async mostrarToast(mensagem: string) {
    const toast = await this.toastController.create({
      message: mensagem,
      duration: 1500,
      color: 'primary',
      position: 'bottom'
    });
    toast.present();
  }

}