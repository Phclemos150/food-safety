import { Component, OnInit } from '@angular/core';
import { FavoritosService } from '../services/favorites.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-favoritos',
  templateUrl: './favoritos.page.html',
  styleUrls: ['./favoritos.page.scss'],
  standalone: false
})
export class FavoritosPage implements OnInit {
  favoritos: any[] = [];

  constructor(
    private favoritosService: FavoritosService,
    private router: Router
  ) {}

  ngOnInit() {
    this.carregarFavoritos();
  }

  carregarFavoritos() {
    this.favoritos = this.favoritosService.getFavoritos();
  }

  abrirDetalhe(id: string) {
    this.router.navigate(['/detalhe', id]);
  }

  removerFavorito(id: string, event: Event) {
    event.stopPropagation();  // evita abrir o detalhe ao clicar no coração
    this.favoritosService.removerFavorito(id);
    this.carregarFavoritos();  // atualiza lista local para refletir a remoção
  }
}
