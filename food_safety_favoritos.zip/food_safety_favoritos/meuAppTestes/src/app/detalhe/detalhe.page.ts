import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { HttpClient } from '@angular/common/http';
import { FavoritosService } from '../services/favorites.service';
import { ToastController } from '@ionic/angular'; // ✅ importado aqui

@Component({
  selector: 'app-detalhe',
  templateUrl: './detalhe.page.html',
  styleUrls: ['./detalhe.page.scss'],
  standalone: false,
})
export class DetalhePage implements OnInit {
  receita: any;

  constructor(
    private route: ActivatedRoute,
    private http: HttpClient,
    private favoritosService: FavoritosService,
    private toastController: ToastController // ✅ injeção
  ) {}

  ngOnInit() {
    const id = this.route.snapshot.paramMap.get('id');
    this.http.get<any>(`https://www.themealdb.com/api/json/v1/1/lookup.php?i=${id}`)
      .subscribe(res => {
        this.receita = res.meals[0];
      });
  }

  toggleFavorito() {
    const mensagem = this.isFavorito()
      ? 'Removido dos favoritos'
      : 'Adicionado aos favoritos';

    this.favoritosService.toggleFavorito(this.receita);
    this.mostrarToast(mensagem);
  }

  isFavorito(): boolean {
    return this.receita ? this.favoritosService.isFavorito(this.receita.idMeal) : false;
  }

  async mostrarToast(mensagem: string) {
    const toast = await this.toastController.create({
      message: mensagem,
      duration: 1500,
      color: 'primary',
      position: 'bottom'
    });
    toast.present();
  }
}
